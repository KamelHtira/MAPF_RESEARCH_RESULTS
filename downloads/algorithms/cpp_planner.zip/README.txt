C++ planner for the League of Robot Runners start-kit v1.1.5 (2023).
Copy src/MAPFPlanner.cpp and inc/MAPFPlanner.h over the files of the same name in the kit and build it without Python:
  cmake -B build ./ -DCMAKE_BUILD_TYPE=Release -DPYTHON=OFF && make -C build -j
Switches (environment variables): WAIT_ACTION, PRIORITY_SWAP, EMPTY_PATH_SWAP, DETOUR_LIMIT, DETOUR_MARGIN, ASTAR_CAP, TIE_SEED. See the comment at the top of MAPFPlanner.cpp.
WAIT_ACTION=0 PRIORITY_SWAP=0 runs the original default planner.
