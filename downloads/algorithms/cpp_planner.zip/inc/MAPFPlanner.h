#pragma once
#include <ctime>
#include <cstdint>
#include <deque>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include "SharedEnv.h"
#include "ActionModel.h"

// C++ port of the Python planner (Start-Kit-wait-priority-v2): prioritized planning with space-time A*,
// optional WAIT move in the A*, optional priority swap (also when the A* finds no path at all), and the
// original conflict fallback. Switches are read from environment variables, see MAPFPlanner.cpp.
class MAPFPlanner
{
public:
    SharedEnvironment* env;

    MAPFPlanner(SharedEnvironment* env): env(env){};
    MAPFPlanner(){env = new SharedEnvironment();};
    virtual ~MAPFPlanner(){delete env;};

    virtual void initialize(int preprocess_time_limit);

    // return next actions for all agents
    virtual void plan(int time_limit, std::vector<Action> & plan);

private:
    typedef std::pair<int,int> Step;   // (cell, facing)
    struct RT { int a, b, t; };        // one reservation: vertex (cell, -1, t) or swap (from, to, t)

    // settings (environment variables)
    int waitAction = 1;
    int prioritySwap = 1;
    int emptyPathSwap = 1;
    int detourLimit = 6;
    int detourMargin = 3;
    long astarCap = 0;                 // 0 = no limit
    int swapLog = 1;
    uint64_t rng = 1;
    bool exactMode = false;            // TIE_SEED=0: deterministic rules identical to a Python copy (for testing)

    int curTime = -1;
    std::vector<std::deque<Step>> paths;
    std::unordered_set<uint64_t> reservation;
    std::vector<int> agentAt;          // cell -> robot standing there (-1 = none)
    std::vector<int> lastLocs;
    std::unordered_map<uint64_t, int> idealCache;
    long astarCapped = 0;
    long swapCount = 0;
    long emptyPathSwapCount = 0;

    uint32_t nextTie();
    int manhattan(int a, int b) const;
    bool validateMove(int loc, int loc2) const;
    std::vector<Step> aStar(int start, int startDir, int goal, bool useReservation);
    int idealLen(int start, int ori, int goal);

    template <class P> std::vector<RT> resTuples(const P& path) const;
    void addKeys(const std::vector<RT>& v);
    void reservePath(const std::vector<Step>& path);
    Action firstAction(int i) const;
    std::vector<int> blockers(int i, const std::vector<Step>& idealPath) const;
    std::vector<Step> trySwap(int i, int goal, const std::vector<Step>& path, std::vector<Action>& actions);
    bool findConflicts(std::vector<int>& out) const;
};
