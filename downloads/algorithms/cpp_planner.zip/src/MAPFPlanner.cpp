#include <MAPFPlanner.h>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <queue>

/*
  C++ port of python/pyMAPFPlanner.py of Start-Kit-wait-priority-v2 (the professor's prioritized planner plus my changes).

  Environment variables (all optional):
    WAIT_ACTION=1       the A* may also wait in place (0 = only forward / turn, the professor's original)
    PRIORITY_SWAP=1     when a robot's path is DETOUR_LIMIT or more ticks longer than its ideal path, the robot plans first and
                        the robots blocking its ideal route replan around it (kept if both together save DETOUR_MARGIN ticks)
    EMPTY_PATH_SWAP=1   the swap is also tried when the A* finds no path at all (v2). 0 = v1 behaviour.
    DETOUR_LIMIT=6  DETOUR_MARGIN=3
    ASTAR_CAP           stop one A* search after this many expansions (returns no path). Default 1000000 when WAIT_ACTION=1
                        (the Python version used 100000, which long paths on the 140x500 maps exceed), no limit otherwise. 0 = no limit.
    TIE_SEED=1          the Python version breaks ties between equal-cost A* nodes with id() (a memory address, so it changes
                        from run to run). Here the tie-break is a seeded random number; change the seed for another run.
                        TIE_SEED=0 is a test mode: ties are broken in insertion order, which a patched Python copy can reproduce,
                        so both planners should give identical actions.
    SWAP_LOG=1          print one line per priority swap
  WAIT_ACTION=0 PRIORITY_SWAP=0 gives the professor's original planner.
*/

namespace
{
int envInt(const char* name, int def)
{
    const char* v = std::getenv(name);
    if (v == nullptr || *v == '\0') return def;
    return std::atoi(v);
}

// (a, b, t): a < 2^20, b + 1 < 2^20, t < 2^24
inline uint64_t rkey(int a, int b, int t)
{
    return ((uint64_t)a << 44) | ((uint64_t)(b + 1) << 24) | (uint64_t)t;
}
}


void MAPFPlanner::initialize(int preprocess_time_limit)
{
    waitAction = envInt("WAIT_ACTION", 1);
    prioritySwap = envInt("PRIORITY_SWAP", 1);
    emptyPathSwap = envInt("EMPTY_PATH_SWAP", 1);
    detourLimit = envInt("DETOUR_LIMIT", 6);
    detourMargin = envInt("DETOUR_MARGIN", 3);
    astarCap = envInt("ASTAR_CAP", waitAction ? 1000000 : 0);
    swapLog = envInt("SWAP_LOG", 1);
    exactMode = envInt("TIE_SEED", 1) == 0;
    rng = 0x9E3779B97F4A7C15ULL * (uint64_t)(envInt("TIE_SEED", 1) + 1);
    if (rng == 0) rng = 1;

    int n = env->num_of_agents;
    paths.assign(n, std::deque<Step>());
    agentAt.assign(env->map.size(), -1);
    lastLocs.clear();
    std::cout << "MAPFPlanner (C++ port) ready: WAIT_ACTION=" << waitAction << " PRIORITY_SWAP=" << prioritySwap
              << " EMPTY_PATH_SWAP=" << emptyPathSwap << " ASTAR_CAP=" << astarCap << std::endl;
}


uint32_t MAPFPlanner::nextTie()
{
    rng ^= rng >> 12; rng ^= rng << 25; rng ^= rng >> 27;
    return (uint32_t)((rng * 0x2545F4914F6CDD1DULL) >> 32);
}


int MAPFPlanner::manhattan(int a, int b) const
{
    int ax = a / env->cols, ay = a % env->cols;
    int bx = b / env->cols, by = b % env->cols;
    return abs(ax - bx) + abs(ay - by);
}


bool MAPFPlanner::validateMove(int loc, int loc2) const
{
    int x = loc / env->cols, y = loc % env->cols;
    if (x < 0 || x >= env->rows || y < 0 || y >= env->cols || env->map[loc] == 1)
        return false;
    int x2 = loc2 / env->cols, y2 = loc2 % env->cols;
    if (abs(x - x2) + abs(y - y2) > 1)
        return false;
    return true;
}


// space-time A*: node = (cell, facing, time). Same rules as the Python space_time_plan.
std::vector<MAPFPlanner::Step> MAPFPlanner::aStar(int start, int startDir, int goal, bool useReservation)
{
    struct Node { int loc, dir, g, parent; };
    struct Open { int f; uint32_t tie; int g, loc, dir, parent; };
    auto cmp = [](const Open& a, const Open& b) { return a.f != b.f ? a.f > b.f : a.tie > b.tie; };
    std::priority_queue<Open, std::vector<Open>, decltype(cmp)> open(cmp);
    std::vector<Node> pool;
    std::unordered_set<uint64_t> closed;
    const int mapSize = (int)env->map.size();
    const int cols = env->cols;

    // exact mode (TIE_SEED=0): ties are broken in insertion order and the path is rebuilt from "the last node that pushed this
    // (cell, facing, time)", as the Python dictionary does. Used to compare against a Python copy with the same rules.
    const bool exact = exactMode;
    std::unordered_map<uint64_t, uint64_t> lastParent;
    uint32_t counter = 0;

    open.push(Open{manhattan(start, goal), exact ? counter++ : nextTie(), 0, start, startDir, -1});
    while (!open.empty())
    {
        Open e = open.top();
        open.pop();
        uint64_t ck = ((uint64_t)(e.loc * 4 + e.dir) << 24) | (uint64_t)e.g;
        if (!closed.insert(ck).second)
            continue;
        int idx = (int)pool.size();
        pool.push_back(Node{e.loc, e.dir, e.g, e.parent});
        if (astarCap > 0 && (long)closed.size() > astarCap)
        {
            astarCapped++;
            if (swapLog) std::cout << "[wait] A* stopped after " << astarCap << " expansions (start " << start / cols << "," << start % cols
                                   << " goal " << goal / cols << "," << goal % cols << ")" << std::endl;
            return {};
        }
        if (e.loc == goal)
        {
            std::vector<Step> path;
            if (exact)
            {
                uint64_t k = ck;
                while (true)
                {
                    int state = (int)(k >> 24);
                    path.push_back(Step(state / 4, state % 4));
                    auto it = lastParent.find(k);
                    if (it == lastParent.end()) break;
                    k = it->second;
                }
            }
            else
            {
                for (int k = idx; k != -1; k = pool[k].parent)
                    path.push_back(Step(pool[k].loc, pool[k].dir));
            }
            path.pop_back();   // the start itself
            std::reverse(path.begin(), path.end());
            return path;
        }

        int nl[4], nd[4], cnt = 0;
        int cand[4] = {e.loc + 1, e.loc + cols, e.loc - 1, e.loc - cols};
        int fwd = cand[e.dir];
        if (fwd >= 0 && fwd < mapSize && validateMove(fwd, e.loc)) { nl[cnt] = fwd; nd[cnt] = e.dir; cnt++; }
        nl[cnt] = e.loc; nd[cnt] = (e.dir + 3) % 4; cnt++;   // turn left
        nl[cnt] = e.loc; nd[cnt] = (e.dir + 1) % 4; cnt++;   // turn right
        if (waitAction) { nl[cnt] = e.loc; nd[cnt] = e.dir; cnt++; }

        for (int k = 0; k < cnt; k++)
        {
            int t = curTime + e.g + 1;
            if (useReservation)
            {
                if (reservation.count(rkey(nl[k], -1, t))) continue;
                if (reservation.count(rkey(nl[k], e.loc, t))) continue;
            }
            uint64_t nk = ((uint64_t)(nl[k] * 4 + nd[k]) << 24) | (uint64_t)(e.g + 1);
            if (closed.count(nk)) continue;
            if (exact) lastParent[nk] = ck;
            open.push(Open{e.g + 1 + manhattan(nl[k], goal), exact ? counter++ : nextTie(), e.g + 1, nl[k], nd[k], idx});
        }
    }
    return {};
}


// length of the best path with every other robot removed
int MAPFPlanner::idealLen(int start, int ori, int goal)
{
    uint64_t key = ((uint64_t)start * 4 + ori) * (uint64_t)env->map.size() + (uint64_t)goal;
    auto it = idealCache.find(key);
    if (it != idealCache.end()) return it->second;
    int len = (int)aStar(start, ori, goal, false).size();
    idealCache[key] = len;
    return len;
}


// the reservations a path holds: step t is at time curTime + t; swap entries only from the second step on
template <class P>
std::vector<MAPFPlanner::RT> MAPFPlanner::resTuples(const P& path) const
{
    std::vector<RT> out;
    out.reserve(path.size() * 2);
    int last = -1, t = 1;
    for (const auto& p : path)
    {
        out.push_back(RT{p.first, -1, curTime + t});
        if (last != -1) out.push_back(RT{last, p.first, curTime + t});
        last = p.first;
        t++;
    }
    return out;
}


void MAPFPlanner::addKeys(const std::vector<RT>& v)
{
    for (const RT& r : v) reservation.insert(rkey(r.a, r.b, r.t));
}


void MAPFPlanner::reservePath(const std::vector<Step>& path)
{
    addKeys(resTuples(path));
}


// the action robot i takes this tick if it follows its stored path
Action MAPFPlanner::firstAction(int i) const
{
    const std::deque<Step>& path = paths[i];
    const State& cur = env->curr_states[i];
    if (!path.empty())
    {
        if (path.front().first != cur.location) return Action::FW;
        if (path.front().second != cur.orientation)
        {
            int incr = path.front().second - cur.orientation;
            if (incr == 1 || incr == -3) return Action::CR;
            if (incr == -1 || incr == 3) return Action::CCR;
        }
    }
    return Action::W;
}


// robots whose reserved paths cross robot i's ideal path (same cell at the same time, or a head-on swap),
// the one that crosses it earliest first; at most 3
std::vector<int> MAPFPlanner::blockers(int i, const std::vector<Step>& idealPath) const
{
    std::vector<RT> mine = resTuples(idealPath);
    std::unordered_map<uint64_t, int> index;     // reservation -> first position in `mine`
    for (int k = 0; k < (int)mine.size(); k++)
        index.emplace(rkey(mine[k].a, mine[k].b, mine[k].t), k);

    std::vector<std::pair<int, int>> found;      // (time of first crossing, robot)
    for (int j = 0; j < env->num_of_agents; j++)
    {
        if (j == i || paths[j].empty()) continue;
        int best = (int)mine.size();
        int last = -1, t = 1;
        auto look = [&](int a, int b, int tt) {
            auto it = index.find(rkey(a, b, tt));
            if (it != index.end() && it->second < best) best = it->second;
        };
        for (const Step& p : paths[j])
        {
            int tt = curTime + t;
            look(p.first, -1, tt);                       // same cell at the same time
            if (last != -1)
            {
                look(last, p.first, tt);                 // same swap entry
                look(p.first, last, tt);                 // head-on: they move the other way
            }
            last = p.first;
            t++;
        }
        if (best < (int)mine.size()) found.push_back(std::make_pair(mine[best].t, j));
    }
    std::sort(found.begin(), found.end());
    std::vector<int> out;
    for (size_t k = 0; k < found.size() && k < 3; k++) out.push_back(found[k].second);
    return out;
}


// Robot i has a very long path or none. For each robot j that blocks its ideal route: let i plan first without j's
// reservations, then j replan around i's new path. Keep the best option. Returns i's path.
std::vector<MAPFPlanner::Step> MAPFPlanner::trySwap(int i, int goal, const std::vector<Step>& path, std::vector<Action>& actions)
{
    const State cur = env->curr_states[i];
    std::vector<Step> idealPath = aStar(cur.location, cur.orientation, goal, false);
    const bool noPath = path.empty();
    if (idealPath.empty()) return path;

    int bestGain = 0, bestJ = -1;
    std::vector<Step> bestAltI, bestAltJ;
    for (int j : blockers(i, idealPath))
    {
        if (env->goal_locations[j].empty()) continue;
        const State sj = env->curr_states[j];
        int goalJ = env->goal_locations[j][0].first;

        // work on the real reservation set and undo it afterwards (a copy of the whole set per candidate is too slow)
        struct Undo { uint64_t key; bool wasRemoved; };
        std::vector<Undo> log;
        auto removeAll = [&](const std::vector<RT>& v) {
            for (const RT& r : v) { uint64_t k = rkey(r.a, r.b, r.t); if (reservation.erase(k)) log.push_back(Undo{k, true}); }
        };
        auto addAll = [&](const std::vector<RT>& v) {
            for (const RT& r : v) { uint64_t k = rkey(r.a, r.b, r.t); if (reservation.insert(k).second) log.push_back(Undo{k, false}); }
        };
        auto rollback = [&]() {
            for (size_t k = log.size(); k-- > 0;)
            {
                if (log[k].wasRemoved) reservation.insert(log[k].key);
                else reservation.erase(log[k].key);
            }
            log.clear();
        };

        removeAll(resTuples(paths[j]));
        std::vector<Step> altI = aStar(cur.location, cur.orientation, goal, true);
        if (altI.empty()) { rollback(); continue; }
        addAll(resTuples(altI));
        std::vector<Step> altJ = aStar(sj.location, sj.orientation, goalJ, true);
        rollback();
        if (altJ.empty()) continue;

        int gain = noPath ? -((int)altI.size() + (int)altJ.size())
                          : ((int)path.size() + (int)paths[j].size()) - ((int)altI.size() + (int)altJ.size());
        if (bestJ == -1 || gain > bestGain)
        {
            bestGain = gain; bestJ = j; bestAltI = altI; bestAltJ = altJ;
        }
    }
    if (bestJ == -1 || (!noPath && bestGain < detourMargin)) return path;

    swapCount++;
    if (noPath) emptyPathSwapCount++;
    if (swapLog)
    {
        if (noPath)
            std::cout << "[swap] t=" << curTime << " robot " << i << " at (" << cur.location / env->cols << ", " << cur.location % env->cols
                      << "): NO path -> robot " << bestJ << " replans (" << paths[bestJ].size() << " -> " << bestAltJ.size()
                      << " ticks), robot " << i << " now needs " << bestAltI.size() << std::endl;
        else
            std::cout << "[swap] t=" << curTime << " robot " << i << " at (" << cur.location / env->cols << ", " << cur.location % env->cols
                      << "): planned " << path.size() << " ticks vs ideal " << idealLen(cur.location, cur.orientation, goal)
                      << " -> robot " << bestJ << " replans (" << paths[bestJ].size() << " -> " << bestAltJ.size()
                      << " ticks), robot " << i << " now needs " << bestAltI.size() << std::endl;
    }
    // new reservations = (old - j's old path) + i's new path + j's new path
    for (const RT& r : resTuples(paths[bestJ])) reservation.erase(rkey(r.a, r.b, r.t));
    addKeys(resTuples(bestAltI));
    addKeys(resTuples(bestAltJ));
    paths[bestJ] = std::deque<Step>(bestAltJ.begin(), bestAltJ.end());
    actions[bestJ] = firstAction(bestJ);
    return bestAltI;
}


// robots that would collide this tick if they all followed their paths (same rule as the Python find_conflicts)
bool MAPFPlanner::findConflicts(std::vector<int>& out) const
{
    out.clear();
    const int cols = env->cols;
    const int size = (int)env->map.size();
    for (int i = 0; i < env->num_of_agents; i++)
    {
        const State& st = env->curr_states[i];
        if (paths[i].empty() || paths[i].front().first == st.location) continue;   // this robot does not move
        int location = st.location;
        int cand[4] = {location + 1, location + cols, location - 1, location - cols};
        int forward = cand[st.orientation];
        int around[5] = {forward, forward + 1, forward + cols, forward - 1, forward - cols};
        bool flagged = false;
        for (int c : around)
        {
            if (c < 0 || c >= size) continue;
            int j = agentAt[c];
            if (j < 0 || j == i) continue;
            const std::deque<Step>& pj = paths[j];
            bool jNoMove = pj.empty() || pj.front().first == forward;
            bool jBack = !pj.empty() && pj.front().first == location;
            bool jIsThere = env->curr_states[j].location == forward;
            bool jGoesThere = !pj.empty() && pj.front().first == forward;
            if ((jIsThere && (jNoMove || jBack)) || jGoesThere)
                flagged = true;
        }
        if (flagged) out.push_back(i);
    }
    return !out.empty();
}


void MAPFPlanner::plan(int time_limit, std::vector<Action> & actions)
{
    curTime++;
    const int n = env->num_of_agents;
    actions.assign(n, Action::W);
    if ((int)paths.size() != n) paths.assign(n, std::deque<Step>());
    if (agentAt.size() != env->map.size()) agentAt.assign(env->map.size(), -1);

    // where everybody stands now
    for (int loc : lastLocs) if (loc >= 0) agentAt[loc] = -1;
    lastLocs.resize(n);
    for (int i = 0; i < n; i++) { agentAt[env->curr_states[i].location] = i; lastLocs[i] = env->curr_states[i].location; }

    // reservations of past times are never looked at again
    if (curTime % 32 == 0)
        for (auto it = reservation.begin(); it != reservation.end();)
            it = ((int)(*it & 0xFFFFFF) <= curTime) ? reservation.erase(it) : std::next(it);

    for (int i = 0; i < n; i++)
        if (env->goal_locations[i].empty())
            reservation.insert(rkey(env->curr_states[i].location, -1, curTime + 1));

    for (int i = 0; i < n; i++)
    {
        const State cur = env->curr_states[i];
        if (paths[i].empty())
        {
            std::vector<Step> path;
            if (!env->goal_locations[i].empty())
            {
                int goal = env->goal_locations[i][0].first;
                path = aStar(cur.location, cur.orientation, goal, true);
                if (prioritySwap)
                {
                    if (path.empty())
                    {
                        if (emptyPathSwap) path = trySwap(i, goal, path, actions);
                    }
                    else if ((int)path.size() - idealLen(cur.location, cur.orientation, goal) >= detourLimit)
                    {
                        path = trySwap(i, goal, path, actions);
                    }
                }
            }
            paths[i] = std::deque<Step>(path.begin(), path.end());
            reservePath(path);
        }

        const std::deque<Step>& path = paths[i];
        if (!path.empty())
        {
            if (path.front().first != cur.location)
                actions[i] = Action::FW;
            else if (path.front().second != cur.orientation)
            {
                int incr = path.front().second - cur.orientation;
                if (incr == 1 || incr == -3) actions[i] = Action::CR;
                else if (incr == -1 || incr == 3) actions[i] = Action::CCR;
            }
        }
    }

    // safety net: a robot that would collide drops its path and turns in place
    std::vector<int> conflicts;
    while (findConflicts(conflicts))
    {
        for (int i : conflicts)
        {
            const State& st = env->curr_states[i];
            for (const RT& r : resTuples(paths[i])) reservation.erase(rkey(r.a, r.b, r.t));
            paths[i].clear();
            paths[i].push_back(Step(st.location, (st.orientation + 1) % 4));
            reservation.insert(rkey(st.location, -1, curTime + 1));
            actions[i] = Action::CR;
        }
    }

    for (int i = 0; i < n; i++)
        if (!paths[i].empty()) paths[i].pop_front();
}
