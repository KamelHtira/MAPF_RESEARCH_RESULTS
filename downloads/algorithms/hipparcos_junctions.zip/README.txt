Hipparcos 2024 planner with the base points on the junctions of the map skeleton.

Copy these files over the same paths in the start kit of Team Hipparcos (2024 competition code archive) and build as usual.

  inc, src/map_utils/Skeleton     new: the skeleton of the map (the map reduction of the waypoint planner)
  inc, src/map_utils/MapUtils     base points on skeleton junctions instead of a uniform grid
  src/PIBT/PIBT.cpp               smallest distance between two base points: 10 (environment variable JUNCTION_MIN_DIST)
  MapUtils, Agent, Agent2,        a bounds check before the map is read in validateMove (the new base points reach the
  Replan, RRAStar                 map border, where the original code reads outside the map)
