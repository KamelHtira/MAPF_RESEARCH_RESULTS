#ifndef SKELETON_H
#define SKELETON_H

#include <vector>
#include "SharedEnv.h"

// The skeleton of a map as the waypoint planner builds it (its map reduction): every free cell gets its distance to the nearest obstacle,
// then the cells next to an obstacle that are not needed for the connection are removed layer by layer, and the dead-end spurs after each
// layer. What stays is a thin network of corridors and crossroads. In big open areas a grid of `step` cells keeps the space from staying empty.
class Skeleton {
public:
    Skeleton(const SharedEnvironment* env, int step);

    bool contains(int loc) const { return reduced[loc] > 0; }
    int neighbours(int loc) const;                    // skeleton cells among the four neighbours of a cell

private:
    int rows, cols, step;
    std::vector<int> reduced;                         // > 0: part of the skeleton, the distance to the nearest removed cell or obstacle

    void start(const SharedEnvironment* env);
    void update();
    bool reduce(bool keepSalient);
    bool areNeighboursTraversable(int loc) const;
    int countVertical(int loc) const;
    int countHorizontal(int loc) const;
};

#endif // SKELETON_H
