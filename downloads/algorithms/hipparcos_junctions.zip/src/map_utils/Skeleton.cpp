#include "map_utils/Skeleton.h"
#include <algorithm>

Skeleton::Skeleton(const SharedEnvironment* env, int step) : rows(env->rows), cols(env->cols), step(step) {
    start(env);
    while (reduce(true)) { reduce(false); }
}

int Skeleton::neighbours(int loc) const {
    return countVertical(loc) + countHorizontal(loc);
}

// distance to the nearest obstacle (four sweeps over the map); on a grid of `step` cells the distance restarts at 0 in open areas
void Skeleton::start(const SharedEnvironment* env) {
    reduced.assign((size_t)rows * cols, 0);
    auto sweep = [&](int x, int y, int& distance, bool first) {
        const int loc = x * cols + y;
        distance = env->map[loc] == 1 ? 0 : (first ? distance + 1 : std::min(distance + 1, reduced[loc]));
        if (distance > step && x % step == 0 && y % step == 0) { distance = 0; }
        reduced[loc] = distance;
    };
    int distance;
    for (int x = 0; x < rows; ++x)        { distance = 0; for (int y = 0; y < cols; ++y)        { sweep(x, y, distance, true); } }
    for (int x = rows - 1; x >= 0; --x)   { distance = 0; for (int y = cols - 1; y >= 0; --y)   { sweep(x, y, distance, false); } }
    for (int y = 0; y < cols; ++y)        { distance = 0; for (int x = 0; x < rows; ++x)        { sweep(x, y, distance, false); } }
    for (int y = cols - 1; y >= 0; --y)   { distance = 0; for (int x = rows - 1; x >= 0; --x)   { sweep(x, y, distance, false); } }
}

// the same four sweeps, every removed cell or obstacle (value 0) is a source
void Skeleton::update() {
    auto sweep = [&](int x, int y, int& distance) {
        const int loc = x * cols + y;
        distance = reduced[loc] == 0 ? 0 : std::min(distance + 1, reduced[loc]);
        reduced[loc] = distance;
    };
    int distance;
    for (int x = 0; x < rows; ++x)        { distance = 0; for (int y = 0; y < cols; ++y)        { sweep(x, y, distance); } }
    for (int x = rows - 1; x >= 0; --x)   { distance = 0; for (int y = cols - 1; y >= 0; --y)   { sweep(x, y, distance); } }
    for (int y = 0; y < cols; ++y)        { distance = 0; for (int x = 0; x < rows; ++x)        { sweep(x, y, distance); } }
    for (int y = cols - 1; y >= 0; --y)   { distance = 0; for (int x = rows - 1; x >= 0; --x)   { sweep(x, y, distance); } }
}

// keepSalient: remove the cells next to an obstacle that are not needed for the connection; otherwise remove the dead-end spurs
bool Skeleton::reduce(bool keepSalient) {
    bool changed = false;
    const int n = (int)reduced.size();
    if (keepSalient) {
        for (int i = 0; i < n; ++i) {
            if (reduced[i] == 1 && areNeighboursTraversable(i) && countVertical(i) + countHorizontal(i) > 1) {
                changed = true;
                reduced[i] = 0;
            }
        }
    } else {
        std::vector<int> next = reduced;
        for (int i = 0; i < n; ++i) {
            if (reduced[i] == 1 && countVertical(i) + countHorizontal(i) == 1) {
                changed = true;
                next[i] = 0;
            }
        }
        reduced = next;
    }
    update();
    return changed;
}

// false for a bridge cell and for the corner cases of 2 x 2 blocks
bool Skeleton::areNeighboursTraversable(int loc) const {
    const int n = (int)reduced.size(), x = loc / cols, y = loc % cols;
    const int h = countHorizontal(loc), v = countVertical(loc);
    if ((v == 0 && h == 2) || (v == 2 && h == 0)) { return false; }
    const bool north = loc >= cols && reduced[loc - cols] > 0, south = loc + cols < n && reduced[loc + cols] > 0;
    const bool east = y + 1 < cols && reduced[loc + 1] > 0, west = y > 0 && reduced[loc - 1] > 0;
    if (north && east && !(x > 0 && y + 1 < cols && reduced[loc - cols + 1] > 0)) { return false; }
    if (south && east && !(x + 1 < rows && y + 1 < cols && reduced[loc + cols + 1] > 0)) { return false; }
    if (south && west && !(x + 1 < rows && reduced[loc + cols - 1] > 0)) { return false; }
    if (north && west && !(x > 0 && y > 0 && reduced[loc - cols - 1] > 0)) { return false; }
    return true;
}

int Skeleton::countVertical(int loc) const {
    int count = 0;
    if (loc >= cols && reduced[loc - cols] > 0) { ++count; }
    if (loc + cols < (int)reduced.size() && reduced[loc + cols] > 0) { ++count; }
    return count;
}

int Skeleton::countHorizontal(int loc) const {
    int count = 0;
    const int y = loc % cols;
    if (y > 0 && reduced[loc - 1] > 0) { ++count; }
    if (y + 1 < cols && reduced[loc + 1] > 0) { ++count; }
    return count;
}
