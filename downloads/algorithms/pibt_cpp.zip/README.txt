PIBT of Team Hipparcos (2024 competition, MAPF-Competition/Code-Archive), run in the League of Robot Runners start-kit v1.1.5 (2023).

src/PIBT/PIBT.cpp, src/PIBT/Agent.cpp, inc/PIBT/PIBT.h, inc/PIBT/Agent.h  : the team's files, unchanged.
inc/RRA_star/RRAstar.h : a stand-in for the team's RRA* class that only gives Manhattan distance (all PIBT.cpp uses on warehouse and sortation maps).
                         On other maps the original uses RRA*, so results there would not be the original algorithm.
src/MAPFPlanner.cpp, inc/MAPFPlanner.h : glue between the start-kit and PIBT (converts the time limit from seconds to milliseconds).

Build changes in the start-kit: add this line to inc/common.h
    using TimePoint = std::chrono::steady_clock::time_point;     (and #include <chrono>)
and in CMakeLists.txt use  file(GLOB_RECURSE SOURCES "src/*.cpp")  and add  thread  to the Boost components.
Then:  cmake -B build ./ -DCMAKE_BUILD_TYPE=Release -DPYTHON=OFF && make -C build -j
