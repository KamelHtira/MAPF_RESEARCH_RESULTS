#pragma once
#include <ctime>
#include "SharedEnv.h"
#include "ActionModel.h"
#include "PIBT/PIBT.h"

// Glue between the start-kit v1.1.5 harness and the professor's PIBT (Team Hipparcos, 2024 competition archive).
class MAPFPlanner
{
public:
    SharedEnvironment* env;
    PIBT* pibt = nullptr;

    MAPFPlanner(SharedEnvironment* env): env(env){};
    MAPFPlanner(){env = new SharedEnvironment();};
    virtual ~MAPFPlanner(){ delete pibt; delete env; };

    virtual void initialize(int preprocess_time_limit);

    // return next actions for all agents
    virtual void plan(int time_limit, std::vector<Action> & plan);
};
