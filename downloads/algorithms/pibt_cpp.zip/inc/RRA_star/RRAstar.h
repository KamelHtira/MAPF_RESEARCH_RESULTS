#pragma once
#include <cstdlib>
#include "SharedEnv.h"

// Stand-in for the team's RRA* heuristic class (their RRA_star folder is not part of this kit).
// PIBT.cpp only uses the Manhattan distance on warehouse and sortation maps (its `manhattan` flag), which is all this class
// provides. On other maps the original would use RRA*; this stand-in falls back to Manhattan distance there,
// so results on non-warehouse maps are NOT the original algorithm.
class RRAstar
{
public:
    RRAstar(SharedEnvironment* _env): env(_env) {}

    void reset() {}
    void initialize(int /*start*/, int /*startDir*/, int _goal) { goal = _goal; }

    int getManhattanDist(int loc, int target) const
    {
        return std::abs(loc / env->cols - target / env->cols) + std::abs(loc % env->cols - target % env->cols);
    }
    int abstractDist(int loc, int /*dir*/) const { return getManhattanDist(loc, goal); }

private:
    SharedEnvironment* env;
    int goal = 0;
};
