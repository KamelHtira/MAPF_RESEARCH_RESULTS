#include <MAPFPlanner.h>

void MAPFPlanner::initialize(int preprocess_time_limit)
{
    pibt = new PIBT(env);
    pibt->initialize();
}

void MAPFPlanner::plan(int time_limit, std::vector<Action> & actions)
{
    // the harness gives the limit in seconds (INT_MAX = none); PIBT::nextStep expects milliseconds
    long long ms = (long long)time_limit * 1000;
    if (ms > 2000000000LL) ms = 2000000000LL;
    pibt->nextStep((int)ms, actions);
}
