Planner of the League of Robot Runners start-kit (2024 style), run in start-kit v1.1.5 (2023): safe interval path planning (SIPP) toward waypoints of a reduced map.

src/MAPFPlanner.cpp and inc/MAPFPlanner.h are unchanged. Copy them over the files of the same name in the kit and build it without Python:
  cmake -B build ./ -DCMAKE_BUILD_TYPE=Release -DPYTHON=OFF && make -C build -j
It builds as it is with the kit's Boost (no other change was needed).
