#pragma once
#include <ctime>
#include <set>
#include <tuple>
#include "SharedEnv.h"
#include "ActionModel.h"


class MAPFPlanner
{
public:
    SharedEnvironment* env;

    typedef enum {WORKER, AID, IDLE} AgentRole;

    unordered_map<tuple<int,int,int>,int> reservation; // edge or cell reservation, agent id
    std::vector<std::set<int>*> sipp_reservation;  //  end of safe intervals for each location  
    std::vector< pair <int,int> > agentPrioritiesSorted;  //  priority of each agent first: priority, second: agent_id
    std::vector<int> agentPriorities;  //  priority of each agent 
    std::vector<AgentRole> agentRoles;  //  role of each agent 
    int selfTime;
    vector<int> assignedDestinations;
    //for each agent
    // first -> location
    // second -> orientation
    std::vector<list<pair<int,int>>> paths ;

    // map reduction related things begin
    unordered_map<int,int> agentMap;
    vector<int> reducedMap;
    vector<int> l0reducedMap;
    vector<int> l1reducedMap;
    vector<int> l2reducedMap;
    vector<unordered_map<int,int>> reducedMapWaypoints;
    vector<int> simpleWaypointDestinations;
    vector<list<int>> waypoints;

    void printReducedMap();
    void hierarchyMapStart(int grid);
    void hierarchyMapWaypointsStart(int grid);
    int hierarchy_single_agent_plan(int start,int start_direct,int end, int top_left_x, int top_left_y, int grid);  // returns the distance 
    void reduceMapStart();
    void reduceMapUpdate();
    bool reduceMap(bool keepSalient);
    void reduceMapWaypointsStart();
    bool reduceReduceMapWaypoints(int distance);
    bool areNeighboursTraversable(int location);
    bool isNorthEastEmpty(int location, int x, int y);
    bool isSouthEastEmpty(int location, int x, int y);
    bool isNorthWestEmpty(int location, int x, int y);
    bool isSouthWestEmpty(int location, int x, int y);
    int countReducedVerticalNeighbours(int location);
    int countReducedHorizontalNeighbours(int location);

    void reducedMapAStar(int start, int end, int step, list<int> & waypoints);
    void reducedMapWaypointsAStar(int start, int end, int step, list<int> & waypoints);
    int BFStoReducedMap(int start);
    std::list<int> getPlainNeighbors(int location);
    std::list<int> getPlainNeighborsOnReducedMap(int location);
    bool validateMoveOnReducedMap(int loc1, int loc2);
    // map reduction related things end



	MAPFPlanner(SharedEnvironment* env): env(env){};
    MAPFPlanner(){env = new SharedEnvironment();};
	virtual ~MAPFPlanner(){delete env;};


    virtual void initialize(int preprocess_time_limit);

    // return next states for all agents
    virtual void plan(int time_limit, std::vector<Action> & plan);
    virtual void plan_with_waypoints(int time_limit, std::vector<Action> & plan);

    // Start kit dummy implementation
    std::list<pair<int,int>>single_agent_plan(int start,int start_direct, int end);
    std::list<pair<int,int>>space_time_plan(int start,int start_direct, int end, unordered_map<tuple<int,int,int>,int> &reservation, vector<int> &agent_hits, bool no_extra=false);
    std::list<pair<int,int>>state_time_plan(int start,int start_direct,int start_time,int end,int near,int depth, unordered_map<tuple<int,int,int>,int> &reservation, vector<int> &agent_hits, list<tuple<int,int,int>> &agent_extra_hits, vector<int> &aid_agents, bool no_extra=false);
    void reserve_path(list<pair<int,int>> path,int agentId); 
    void cancel_path_reservation(list<pair<int,int>> path); 
    int getManhattanDistance(int loc1, int loc2);
    std::list<pair<int,int>> getNeighbors(int location, int direction);
    //getSippNeighbors returns neighbors and their cost and the end of the their safe interval
    std::list<tuple<pair<int,int>,int,int>> getSippNeighbors(int location, int direction, int curr_time, unordered_map<tuple<int,int,int>,int> &reservation); 
    int getSafeIntervalEnd(int location, int curr_time); 
    int getSafeIntervalEndWithCleanup(int location, int curr_time); 
    bool validateMove(int loc,int loc2);
    void updateAgentMap();
    pair<bool, std::vector<int>> findConflicts();
    pair<bool, int> steerAway(int agentId, int loc_from, int loc_to);
    pair<bool, int> forwardMoveConflict(int agentId);
    pair<bool, int> crMoveConflict(int agentId);
};
