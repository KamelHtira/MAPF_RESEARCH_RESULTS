Scenario: 100 robots on the warehouse_small map (33 x 57), 300 time steps.

Run it with a League of Robot Runners start-kit v1.1.5 (from the folder of the kit):
  ./build/lifelong --inputFile <this folder>/warehouse_small_100.json -o result.json --simulationTime 300

Watch a result with PlanViz:
  python script/run.py --map <this folder>/maps/warehouse_small.map --plan result.json
