Scenario: 2 robots on the warehouse_small map (33 x 57), 400 time steps.

Run it with a League of Robot Runners start-kit v1.1.5 (from the folder of the kit):
  ./build/lifelong --inputFile <this folder>/wh_small_2.json -o result.json --simulationTime 400

Watch a result with PlanViz:
  python script/run.py --map <this folder>/maps/warehouse_small.map --plan result.json
